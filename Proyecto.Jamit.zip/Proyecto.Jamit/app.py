from flask import Flask, render_template, request
import requests

app = Flask(__name__)  # Corregí el error de _name_

# Tu API Key de OpenWeatherMap
API_KEY = '36baa57cac282eb297043207f12d64e9'

@app.route('/')
def index():
    return render_template('index.html')  # Carga la plantilla "index.html"

@app.route('/clima', methods=['POST'])
def clima():
    ciudad = request.form.get('ciudad')  # Obtiene la ciudad del formulario
    if ciudad:
        url = f"http://api.openweathermap.org/data/2.5/weather?q={ciudad}&appid={API_KEY}&units=metric"
        response = requests.get(url).json()  # Llama a la API de OpenWeatherMap
        
        if response.get('cod') != 200:  # Verifica si hubo un error en la respuesta
            return render_template('index.html', error="Ciudad no encontrada o problema con la API.")
        
        clima_info = {
            'ciudad': ciudad,
            'descripcion': response['weather'][0]['description'],
            'temperatura': response['main']['temp'],
            'latitud': response['coord']['lat'],
            'longitud': response['coord']['lon']
        }
        return render_template('cv.html', clima_info=clima_info)  # Renderiza "cv.html" con datos de clima
    else:
        return render_template('index.html', error="Por favor ingrese una ciudad.")  # Devuelve un error si la ciudad no está ingresada

@app.route('/cv')
def cv():
    return render_template('cv.html')  # Carga la plantilla "cv.html"

if __name__ == "__main__":  # Corregí el error de _main_
    app.run(debug=True)
